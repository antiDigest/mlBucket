
The initial values have been hardcoded to this assignment:

edgeValues =

     0     2     4     1
     0     0     0     3
     0     0     0     4
     0     0     0     0

The outputs with various values of burnin and its are given in the file

        "OUTPUT.txt"
