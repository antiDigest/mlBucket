
% @author: antriksh
% Version 0: 2/21/2018

function amax = argmax(vector)
    [av,amax] = max(vector);
end