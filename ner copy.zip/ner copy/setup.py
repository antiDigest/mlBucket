from setuptools import setup, find_packages

setup(name='NER',
      version='0.0.1',
      description='Named Entity Recognition Using Conditional Random Fields',
      author='Antriksh Agarwal',
      author_email='antriksh.agarwal1@utdallas.edu',
      url='',
      packages=['.']
      )
